import React from 'react';
import { Play } from 'lucide-react';

interface Video {
  id: number;
  title: string;
  description: string;
  url: string;
}

const videos: Video[] = [
  {
    id: 1,
    title: "Big Buck Bunny",
    description: "A large rabbit deals with three bullies",
    url: "https://storage.googleapis.com/gtv-videos-bucket/sample/BigBuckBunny.mp4"
  },
  {
    id: 2,
    title: "Elephant Dream",
    description: "The first Blender Open Movie from 2006",
    url: "https://storage.googleapis.com/gtv-videos-bucket/sample/ElephantsDream.mp4"
  },
  {
    id: 3,
    title: "For Bigger Blazes",
    description: "HBO GO now works with Chromecast",
    url: "https://storage.googleapis.com/gtv-videos-bucket/sample/ForBiggerBlazes.mp4"
  },
  {
    id: 4,
    title: "For Bigger Escape",
    description: "Introducing Chromecast. The easiest way to enjoy online video on your TV",
    url: "https://storage.googleapis.com/gtv-videos-bucket/sample/ForBiggerEscapes.mp4"
  },
  {
    id: 5,
    title: "For Bigger Fun",
    description: "Introducing Chromecast. The easiest way to enjoy online video on your TV",
    url: "https://storage.googleapis.com/gtv-videos-bucket/sample/ForBiggerFun.mp4"
  }
];

function App() {
  const [selectedVideo, setSelectedVideo] = React.useState<Video>(videos[0]);

  return (
    <div className="min-h-screen bg-gray-900 text-white p-8">
      <div className="max-w-6xl mx-auto">
        <h1 className="text-3xl font-bold mb-8 text-center">معرض الفيديو</h1>
        
        <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
          {/* Main Video Player */}
          <div className="lg:col-span-2">
            <div className="bg-gray-800 rounded-lg overflow-hidden">
              <video 
                src={selectedVideo.url} 
                controls 
                className="w-full aspect-video"
              />
              <div className="p-4">
                <h2 className="text-xl font-bold mb-2">{selectedVideo.title}</h2>
                <p className="text-gray-400">{selectedVideo.description}</p>
              </div>
            </div>
          </div>

          {/* Video List */}
          <div className="lg:col-span-1">
            <div className="bg-gray-800 rounded-lg p-4">
              <h3 className="text-xl font-bold mb-4">قائمة الفيديوهات</h3>
              <div className="space-y-4">
                {videos.map((video) => (
                  <div 
                    key={video.id}
                    onClick={() => setSelectedVideo(video)}
                    className={`cursor-pointer p-3 rounded-lg transition-colors ${
                      selectedVideo.id === video.id 
                        ? 'bg-blue-600' 
                        : 'bg-gray-700 hover:bg-gray-600'
                    }`}
                  >
                    <div className="flex items-center gap-3">
                      <div className="flex-shrink-0">
                        <Play className="w-8 h-8" />
                      </div>
                      <div>
                        <h4 className="font-semibold">{video.title}</h4>
                        <p className="text-sm text-gray-400 line-clamp-1">
                          {video.description}
                        </p>
                      </div>
                    </div>
                  </div>
                ))}
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}

export default App;